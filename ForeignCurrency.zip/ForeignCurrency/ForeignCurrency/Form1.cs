﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace ForeignCurrency
{
    public partial class frmForeign : Form
    {
        double usdRate = Convert.ToDouble(ConfigurationSettings.AppSettings["USD"].ToString());
        double eurRate = Convert.ToDouble(ConfigurationSettings.AppSettings["EUR"].ToString());
        double gbpRate = Convert.ToDouble(ConfigurationSettings.AppSettings["GBP"].ToString());
        double kesRate = Convert.ToDouble(ConfigurationSettings.AppSettings["KES"].ToString());

        List<object> order = new List<object>();

        public frmForeign()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            //payment
            if (cmbPay.SelectedItem.ToString() == "Pay")
            {
                lstOutput.Items.Clear();

                //disable currency field
                cmbCurrency.Enabled = false;

                //USD
                double usd = Convert.ToDouble(txtAmount.Text) * usdRate;
                double usdSurcharge = usd * (7.5 / 100);
                double totalUsd = usd + usdSurcharge;

                lstOutput.Items.Add("--- Amout to be paid in USD ---");

                lstOutput.Items.Add("Sub total amount: " + usd);
                lstOutput.Items.Add("Surcharge amount: " + usdSurcharge);
                lstOutput.Items.Add("Total amount: " + totalUsd);

                lstOutput.Items.Add("");
                lstOutput.Items.Add("============================================");
                lstOutput.Items.Add("");

                order.Add(new
                {
                    ForeignCurrency = "USD",
                    ExchangeRate = usdRate,
                    SurchargePerc = 0.075,
                    AmountPaid = Convert.ToDouble(txtAmount.Text),
                    AmountSurcharge = usdSurcharge,
                    DateCreated = DateTime.Now,
                });

                //--------------------------------------------------------------------------------------

                //GBP
                double gbp = Convert.ToDouble(txtAmount.Text) * gbpRate;
                double gbpSurcharge = gbp * (5 / 100);
                double totalGBP = gbp + gbpSurcharge;

                lstOutput.Items.Add("--- Amout to be paid in GBP ---");

                lstOutput.Items.Add("Sub total amount: " + gbp);
                lstOutput.Items.Add("Surcharge amount: " + gbpSurcharge);
                lstOutput.Items.Add("Total amount: " + totalGBP);

                lstOutput.Items.Add("");
                lstOutput.Items.Add("============================================");
                lstOutput.Items.Add("");

                order.Add(new
                {
                    ForeignCurrency = "GBP",
                    ExchangeRate = gbpRate,
                    SurchargePerc = 0.05,
                    AmountPaid = Convert.ToDouble(txtAmount.Text),
                    AmountSurcharge = gbpSurcharge,
                    DateCreated = DateTime.Now,
                });

                //--------------------------------------------------------------------------------------

                //lstOutput.Items.Add(gbp);

                //EUR
                double eur = Convert.ToDouble(txtAmount.Text) * eurRate;
                double eurSurcharge = eur * (5 / 100);
                double totalEUR = eur + eurSurcharge;

                lstOutput.Items.Add("--- Amout to be paid in EUR ---");

                lstOutput.Items.Add("Sub total amount: " + eur);
                lstOutput.Items.Add("Surcharge amount: " + eurSurcharge);
                lstOutput.Items.Add("Total amount: " + totalEUR);

                lstOutput.Items.Add("");
                lstOutput.Items.Add("============================================");
                lstOutput.Items.Add("");

                order.Add(new
                {
                    ForeignCurrency = "EUR",
                    ExchangeRate = eurRate,
                    SurchargePerc = 0.05,
                    AmountPaid = Convert.ToDouble(txtAmount.Text),
                    AmountSurcharge = eurSurcharge,
                    DateCreated = DateTime.Now,
                });

                //--------------------------------------------------------------------------------------

                //KES
                double kes = Convert.ToDouble(txtAmount.Text) * kesRate;
                double kesSurcharge = kes * (2.5 / 100);
                double totalKES = kes + kesSurcharge;

                lstOutput.Items.Add("--- Amout to be paid in KES ---");

                lstOutput.Items.Add("Sub total amount: " + kes);
                lstOutput.Items.Add("Surcharge amount: " + kesSurcharge);
                lstOutput.Items.Add("Total amount: " + totalKES);

                lstOutput.Items.Add("");
                lstOutput.Items.Add("============================================");
                lstOutput.Items.Add("");

                order.Add(new
                {
                    ForeignCurrency = "KES",
                    ExchangeRate = kesRate,
                    SurchargePerc = 0.025,
                    AmountPaid = Convert.ToDouble(txtAmount.Text),
                    AmountSurcharge = kesSurcharge,
                    DateCreated = DateTime.Now,
                });

            } //purchase
            else
            {
                lstOutput.Items.Clear();
                cmbCurrency.Enabled = true;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //comboBox1.Text = "Pay";
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            var conn = ConfigurationSettings.AppSettings["ForeignExchange"];

            SqlConnection connection = new SqlConnection("Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\\Users\\Manny\\documents\visual studio 2013\\Projects\\ForeignCurrency\\ForeignCurrency\\Foreign.mdf;Integrated Security=True");

            try
            {
                connection.Open();
                MessageBox.Show("Connection successful");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
            
            order.ForEach(o => MessageBox.Show(o.ToString()));
        }

        private void cmbCurrency_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstOutput.Items.Clear();

            double curr = 0.0;
            double surcharge = 0.0;
            double total = 0.0;
            double rate = 0.0;
            double surchargePerc = 0.0;

            switch (cmbCurrency.SelectedItem.ToString())
	        {
                case "EUR":
                    rate = eurRate;
                    surchargePerc = 5;
                    curr = Convert.ToDouble(txtAmount.Text) * rate;
                    surcharge = curr * (surchargePerc / 100);
                    total = curr + surcharge;
                    break;
                case "USD":
                    rate = usdRate;
                    surchargePerc = 7.5;
                    curr = Convert.ToDouble(txtAmount.Text) * rate;
                    surcharge = curr * (surchargePerc / 100);
                    total = curr + surcharge;
                    break;
                case "GBP":
                    rate = gbpRate;
                    surchargePerc = 5;
                    curr = Convert.ToDouble(txtAmount.Text) * rate;
                    surcharge = curr * (surchargePerc / 100);
                    total = curr + surcharge;
                    break;
                case "KES":
                    rate = kesRate;
                    surchargePerc = 2.5;
                    curr = Convert.ToDouble(txtAmount.Text) * rate;
                    surcharge = curr * (surchargePerc / 100);
                    total = curr + surcharge;
                    break;
		        default:
                    lstOutput.Items.Add("No currency selected");
                    break;
	        }

            lstOutput.Items.Add("Sub total amount: " + curr);
            lstOutput.Items.Add("Surcharge amount: " + surcharge);
            lstOutput.Items.Add("Total amount: " + total);

            lstOutput.Items.Add("");
            lstOutput.Items.Add("============================================");
            lstOutput.Items.Add("");

            order.Add(new
            {
                ForeignCurrency = "USD",
                ExchangeRate = rate,
                SurchargePerc = (surchargePerc / 100),
                AmountPaid = Convert.ToDouble(txtAmount.Text),
                AmountSurcharge = surcharge,
                DateCreated = DateTime.Now,
            });
        }
    }
}
